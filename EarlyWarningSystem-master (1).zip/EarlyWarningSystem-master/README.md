 Developed a predictive system to support the educational planning process by identifying students at risk of academic
 failure.
 Utilized data analysis and machine learning techniques to detect early warning signs based on human, student, and
 environmental metrics.
 Enabled educational institutions to take proactive interventions through an intuitive dashboard.
 The system enhances student retention and performance by providing data-driven insights for timely decision-making
